package com.alarmapplication.www.util

        //dialog들에서, 정해놓은 값으로 각각 type에 맞게 선택하기 위해서 따로 생성
const val LOTTE = 0
const val EMART = 1
const val GGANG = 2

const val ASIA = 10
const val EUROPE = 11
const val ASIA_AND_EUROPE = 12

const val NORMAL = 20
const val INCREASE = 21

const val SMALL_VOLUME=25
const val NORMAL_VOLUME=50
const val BIG_VOLUME=75
const val BIGGEST_VOLUME=100